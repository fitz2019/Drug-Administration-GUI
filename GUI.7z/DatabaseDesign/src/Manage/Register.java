package Manage;
import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import JDBC.DataBaseConnection;
public class Register extends JFrame implements ActionListener{
    private static final long serialVersionUID = -364466147708286086L;
    JLabel labelA,labelB,labelC,labelD,labelE,labelF;
    JTextField txt0,txt1,txt2,txt3,txt4,txt5;
    JButton button1,button2,button3;
    String s1,s2,s3,s4,s5,s6;
    public Register() {
        Font font=new Font("微软雅黑",Font.BOLD,16);
        labelA=new JLabel("用户名");
        labelB=new JLabel("密码");
        labelC=new JLabel("真实姓名");
        labelD=new JLabel("性别");
        labelE=new JLabel("年龄");
        labelF=new JLabel("邮箱");

        txt0=new JTextField(10);
        txt1=new JTextField(10);
        txt2=new JTextField(10);
        txt3=new JTextField(10);
        txt4=new JTextField(10);
        txt5=new JTextField(10);

        button1=new JButton("注册");
        button1.addActionListener(this);
        button2=new JButton("清空");
        button2.addActionListener(this);
        button3=new JButton("立即登录");
        button3.addActionListener(this);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);
        button3.setBackground(Color.LIGHT_GRAY);
        button3.setForeground(Color.red);

        labelA.setFont(font);
        labelB.setFont(font);
        labelC.setFont(font);
        labelD.setFont(font);
        labelE.setFont(font);
        labelF.setFont(font);

        labelA.setForeground(Color.blue);
        labelB.setForeground(Color.blue);
        labelC.setForeground(Color.blue);
        labelD.setForeground(Color.blue);
        labelE.setForeground(Color.blue);
        labelF.setForeground(Color.blue);

        labelA.setBounds(100,0,100,100);
        labelB.setBounds(100,50,100,100);
        labelC.setBounds(100,100,100,100);
        labelD.setBounds(100,150,100,100);
        labelE.setBounds(100,200,100,100);
        labelF.setBounds(100,250,100,100);

        txt0.setBounds(230,30,250,40);
        txt1.setBounds(230,80,250,40);
        txt2.setBounds(230,130,250,40);
        txt3.setBounds(230,180,250,40);
        txt4.setBounds(230,230,250,40);
        txt5.setBounds(230,280,250,40);

        button1.setBounds(230,400,80,30);
        button2.setBounds(350,400,80,30);
        button3.setBounds(500,440,100,30);
        add(labelA);
        add(labelB);
        add(labelC);
        add(labelD);
        add(labelE);
        add(labelF);

        add(txt0);
        add(txt1);
        add(txt2);
        add(txt3);
        add(txt4);
        add(txt5);

        add(button1);
        add(button2);
        add(button3);
        setTitle("用户注册");
        setLayout(null);
        setResizable(false);
    }
    public void UserRegister(){
        s1=txt0.getText();
        s2=txt1.getText();
        s3=txt2.getText();
        s4=txt3.getText();
        s5=txt4.getText();
        s6=txt5.getText();

        if (s1.equals("") || s2.equals("") || s3.equals("") || s4.equals("")||s5.equals("")||s6.equals("")) {
            JOptionPane.showMessageDialog(this, "请填写完整！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        else{
            String sql = "insert into administer(User,Password,Name,Sex,Age,Email)"
                    + " values ('" + s1 + "','" + s2 + "','" + s3 + "','" + s4 + "','" + s5 + "','" + s6 + "')";

            try{
                Connection conn = DataBaseConnection.getConnection();
                Statement statement = conn.createStatement();
                statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(this, "注册成功，赶紧登陆吧!", "恭喜", JOptionPane.WARNING_MESSAGE);
            }catch (SQLException e){
                e.printStackTrace();
            }

        }

    }
    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource().equals(button1)) {
            UserRegister();
        }
        else if (e.getSource().equals(button2)) {
            txt0.setText("");
            txt1.setText("");
            txt2.setText("");
            txt3.setText("");
            txt4.setText("");
            txt5.setText("");


        }
        else if (e.getSource().equals(button3)) {
            new AdLogin();
            dispose();
        }
    }
    public static void main(String[] args) {
        Register pr =new Register();
        pr.setBounds(100, 100, 600, 500);
        pr.setVisible(true);
        pr.setLocationRelativeTo(null);

    }
}
