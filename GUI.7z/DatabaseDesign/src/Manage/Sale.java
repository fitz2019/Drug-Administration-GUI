package Manage;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

import JDBC.DataBaseConnection;

public class Sale extends JFrame implements ActionListener {
    private static final long serialVersionUID = -3605968094154844031L;

    String s1, s2, s3, s4, s5, s6, s7, ssum, snum, s8;

    double d2, c2;
    int  c, n, c1;
    float p, d1;

    JLabel labelA, labelB, labelC, labelD, labelE, labelF, labelG;
    JTextField txt1, txt2, txt3, txt4, txt5, txt6, txt7;
    JButton button1, button2, button3;



    public Sale() {
        Font font = new Font("微软雅黑", Font.BOLD, 16);
        labelA = new JLabel("药品编号");
        labelB = new JLabel("药品名称");
        labelC = new JLabel("药品数量");
        labelD = new JLabel("药品单价");
        labelE = new JLabel("订单编号");
        labelF = new JLabel("客户编号");
        labelG = new JLabel("总计");
        labelA.setFont(font);
        labelB.setFont(font);
        labelC.setFont(font);
        labelD.setFont(font);
        labelE.setFont(font);
        labelF.setFont(font);
        labelG.setFont(font);
        labelA.setForeground(Color.BLUE);
        labelB.setForeground(Color.BLUE);
        labelC.setForeground(Color.BLUE);
        labelD.setForeground(Color.BLUE);
        labelE.setForeground(Color.BLUE);
        labelF.setForeground(Color.BLUE);
        labelG.setForeground(Color.BLUE);
        txt1 = new JTextField(10);
        txt2 = new JTextField(10);
        txt3 = new JTextField(10);
        txt4 = new JTextField(10);
        txt5 = new JTextField(10);
        txt6 = new JTextField(10);
        txt7 = new JTextField(10);
        button1 = new JButton("出售");
        button1.addActionListener(this);
        button2 = new JButton("清空");
        button2.addActionListener(this);
        button3 = new JButton("返回");
        button3.addActionListener(this);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);
        button3.setBackground(Color.LIGHT_GRAY);
        button3.setForeground(Color.red);
        labelA.setBounds(80, 0, 100, 100);
        txt1.setBounds(180, 35, 200, 30);
        labelB.setBounds(80, 50, 100, 100);
        txt2.setBounds(180, 85, 200, 30);
        labelC.setBounds(80, 100, 100, 100);
        txt3.setBounds(180, 135, 200, 30);
        labelD.setBounds(80, 150, 100, 100);
        txt4.setBounds(180, 185, 200, 30);
        labelE.setBounds(80, 250, 100, 100);
        txt5.setBounds(180, 235, 200, 30);
        labelF.setBounds(80, 300, 100, 100);
        txt6.setBounds(180, 335, 200, 30);
        labelG.setBounds(80, 200, 100, 100);
        txt7.setBounds(180, 285, 200, 30);
        button1.setBounds(180, 380, 80, 30);
        button2.setBounds(300, 380, 80, 30);
        button3.setBounds(520, 440, 80, 30);
        txt2.setEditable(false);
        txt4.setEditable(false);
        txt5.setEditable(false);
        add(labelA);
        add(labelB);
        add(labelC);
        add(labelD);
        add(labelE);
        add(labelF);
        add(labelG);
        add(txt1);
        add(txt2);
        add(txt3);
        add(txt4);
        add(txt5);
        add(txt6);
        add(txt7);
        add(button1);
        add(button2);
        add(button3);
        button1.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
        setTitle("药品销售");
        setLayout(null);
        setResizable(false);
    }

    public void sale() {
        String sql = "SELECT * FROM medicine WHERE Num='" + txt1.getText() + "'";
        String s = "SELECT * FROM sale WHERE 药品编号='" + txt1.getText() + "'";

        if (txt1.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "请输入药品编号！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (txt3.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "请输入购买数量！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // s5 = txt4.getText();
        if (txt6.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "请输入订单编号！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (txt7.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "请输入客户编号！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            Connection conn = DataBaseConnection.getConnection();
            Statement statement = conn.createStatement();
            ResultSet RS = statement.executeQuery(sql);
            Connection conn1 = DataBaseConnection.getConnection();
            Statement statement1 = conn1.createStatement();
            ResultSet RS1 = statement1.executeQuery(s);
            while (RS.next()) {
                s1 = RS.getString("Num");
                s2 = RS.getString("Name");
                s3 = RS.getString("count");
                s4 = RS.getString("purchase");

            }
            while (RS1.next()) {
                s7 = RS1.getString("销售数量");
                s8 = RS1.getString("销售额");
            }


            p = Float.parseFloat(s4);
            c = Integer.parseInt(s3);
            n = Integer.parseInt(txt3.getText());
            d1 = n * p;
            s5 = "" + d1;
            d2 = c - n;

            s6 = "" + d2;

            if (c < n) {
                JOptionPane.showMessageDialog(this, "库存不足，请重新输入！", "提示", JOptionPane.WARNING_MESSAGE);
                return;
            } else {

                txt2.setText(s2);
                txt4.setText(s4);
                txt5.setText(s5);
            }

            if (s7 != null && s8 != null) {

                c1 = Integer.parseInt(s7);
                c2 = Float.parseFloat(s8);
                c1 = c1 + n;
                c2 = c2 + d1;
                ssum = "" + c2;
                snum = "" + c1;
                String sql5 = "UPDATE  sale SET 销售数量 ='" + snum + "' WHERE 药品编号='" + s1 + "'";
                statement.executeUpdate(sql5);
                String sql6 = "UPDATE  sale SET 销售额 ='" + ssum + "' WHERE 药品编号='" + s1 + "'";
                statement.executeUpdate(sql6);
                String sql2 = "insert into indent"
                        + " values ('" + txt7.getText() + "','" + txt6.getText() + "','" + s1 + "','" + s5 + "')";
                statement.executeUpdate(sql2);
                JOptionPane.showMessageDialog(this, "销售成功！", "恭喜", JOptionPane.WARNING_MESSAGE);
                String sql0 = "UPDATE  medicine SET count ='" + s6 + "' WHERE Num='" + s1 + "'";
                statement.executeUpdate(sql0);
            } else {


                String sql1 = "insert into sale"
                        + " values ('" + txt1.getText() + "','" + txt2.getText() + "','" + txt3.getText() + "','" + s5 + "')";
                statement.executeUpdate(sql1);
                String sql2 = "insert into indent"
                        + " values ('" + txt7.getText() + "','" + txt6.getText() + "','" + s1 + "','" + s5 + "')";
                statement.executeUpdate(sql2);
                JOptionPane.showMessageDialog(this, "销售成功！", "恭喜", JOptionPane.WARNING_MESSAGE);
                String sql0 = "UPDATE  medicine SET count ='" + s6 + "' WHERE Num='" + s1 + "'";
                statement.executeUpdate(sql0);
            }


        } catch (SQLException e) {
        }


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(button1)) {
            sale();
        }
        if (e.getSource().equals(button2)) {
            txt1.setText(null);
            txt2.setText(null);
            txt3.setText(null);
            txt4.setText(null);
            txt5.setText(null);
            txt6.setText(null);
            txt7.setText(null);

        }
        if (e.getSource().equals(button3)) {
            new Menu();
            dispose();
        }
    }

    public static void main(String[] args) {
        Sale sale = new Sale();
        sale.setBounds(100, 100, 600, 500);
        sale.setLocationRelativeTo(null);
        sale.setVisible(true);
    }
}
