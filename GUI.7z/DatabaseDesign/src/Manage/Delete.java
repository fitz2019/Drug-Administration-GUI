package Manage;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import JDBC.DataBaseConnection;
public class Delete  extends JFrame implements ActionListener{
    private static final long serialVersionUID = -2870346077742703670L;

    JLabel labelA,labelB,label;
    JTextField txt1,txt2;

    JButton button1,button2;
    public Delete() {
        Font font =new Font("微软雅黑",Font.BOLD,16);
        labelA=new JLabel("药品编号");
        labelB=new JLabel("药品名称");
        label=new JLabel("请输入要删除的药品编号或药品名称");
        txt1=new JTextField(10);
        txt2=new JTextField(10);
        button1=new JButton("删除");
        button1.addActionListener(this);
        button2=new JButton("返回");
        button2.addActionListener(this);
        labelA.setFont(font);
        labelB.setFont(font);
        label.setFont(font);
        labelA.setForeground(Color.blue);
        labelB.setForeground(Color.blue);
        label.setForeground(Color.red);
        label.setBounds(150,0,500,100);
        labelA.setBounds(100,100,100,100);
        labelB.setBounds(100,200,100,100);
        txt1.setBounds(200,130,200,40);
        txt2.setBounds(200,230,200,40);
        button1.setBounds(200,400,80,30);
        button2.setBounds(320,400,80,30);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);
        add(labelA);
        add(labelB);
        add(label);
        add(txt1);
        add(txt2);
        add(button1);
        add(button2);
        setTitle("删除药品信息");
        setLayout(null);
        setResizable(false);
        button1.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);


    }
    public void delete() {
        String sql=null;
        if (txt1.getText().equals("")&&txt2.getText().equals("")) {
            JOptionPane.showMessageDialog(this, "请输入药品编号或药品名称！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        else if (txt1.getText().equals("")){
            sql ="DELETE  FROM medicine WHERE Name='" + txt2.getText()+ "'";
        }
        else if (txt2.getText().equals("")){
            sql ="DELETE  FROM medicine WHERE Num='" + txt1.getText()+ "'";
        }
        try{
            Connection conn = DataBaseConnection.getConnection();
            Statement statement = conn.createStatement();
            statement.executeUpdate(sql);
            JOptionPane.showMessageDialog(this, "删除成功！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
            //conn.close();
        }catch (SQLException e) {}
    }
    public void actionPerformed(ActionEvent e){
        if (e.getSource().equals(button1)){

            delete();
				/*txt1.setText(null);
				txt2.setText(null);*/

        }
        if (e.getSource().equals(button2)) {
            new Menu();
            dispose();
        }
    }
    public static void main(String[] args) {
        Delete delete=new Delete();
        delete.setBounds(100,100,600,500);
        delete.setVisible(true);
        delete.setLocationRelativeTo(null);

    }
}
