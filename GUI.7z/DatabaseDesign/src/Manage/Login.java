package Manage;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import JDBC.DataBaseConnection;
class AdLogin extends JFrame implements ActionListener {

    private static final long serialVersionUID = -1564219685176362136L;
    JButton button1, button2;
    JTextField text;
    JPasswordField pass; // JPasswordField是一个轻量级组件，允许编辑单行文本，其中视图指示输入的内容，但不显示原始字符。
    JLabel labelA, labelB, labelC;
    public AdLogin() {

        Font font = new Font("微软雅黑", Font.PLAIN, 16);
        Font font2 = new Font("微软雅黑", Font.BOLD, 20);
        labelA = new JLabel("用户名：");
        labelA.setFont(font);
        labelA.setForeground(Color.blue);
        labelB = new JLabel("密   码：");
        labelB.setFont(font);
        labelB.setForeground(Color.blue);
        labelC = new JLabel("请登录：");
        labelC.setForeground(Color.RED);
        labelC.setFont(font2);
        text = new JTextField(10);
        pass = new JPasswordField(10);
        button1 = new JButton("登录");
        button1.addActionListener(this);
        button2 = new JButton("重置");
        button2.addActionListener(this);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);
        labelA.setBounds(100, 50, 100, 100);
        labelB.setBounds(100, 140, 100, 100);
        labelC.setBounds(20, 0, 100, 100);
        text.setBounds(200, 85, 200, 30);
        pass.setBounds(200, 170, 200, 30);
        button1.setBounds(200, 250, 80, 30);
        button2.setBounds(320, 250, 80, 30);
        add(labelA);
        add(labelC);
        add(text);
        add(labelB);
        add(pass);
        add(button1);
        button1.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);

        add(button2);
        setLayout(null);

        setTitle("药品销售管理系统");
        setBounds(200, 200, 600, 400);
        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);

    }

    @SuppressWarnings("deprecation")
    @Override
    public void actionPerformed(ActionEvent e) {
       // checkLoginUser();
        String sql = "SELECT * FROM administer;";
        boolean flag=false;
       if (e.getSource().equals(button1)) {
           try{
               Connection conn = DataBaseConnection.getConnection();
               Statement statement = conn.createStatement();
               ResultSet RS = statement.executeQuery(sql);
               while (RS.next()){

                   if (text.getText().equals(RS.getString("User")) && pass.getText().equals(RS.getString("Password"))) {
                       flag=true;
                       new Menu();
                       setVisible(false);
                       this.dispose();
                       break;

                   }

               }
           }catch (SQLException e1){
               e1.printStackTrace();
           }

             if (flag==false){
                JOptionPane.showMessageDialog(this, "用户名或密码错误", "提示", JOptionPane.WARNING_MESSAGE);
            }
        }

        else if (e.getSource().equals(button2)) {
            text.setText(null);
            pass.setText(null);
        }
    }
}

public class Login {

    public static void main(String[] args) {
         new AdLogin();
    }

}