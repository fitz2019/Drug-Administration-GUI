package Manage;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import  JDBC.DataBaseConnection;
import javax.swing.table.*;
public class Profile extends JFrame implements ActionListener{
    private static final long serialVersionUID = -7247281774110864164L;

    JLabel labelA, labelB,labelC;
    JTextField txt1, txt2;
    JButton button1, button2;

    JTextArea txtArea;
    JScrollPane scrollpane;
    DefaultTableModel model;
    JTable table;
    String s1, s2, s3, s4, s5, s6, s7,s8,s9,s10;
    float f=0,f1=0,f2=0;
    int i=0;
    public Profile() {

        model=new DefaultTableModel();
        model.addColumn("药品编号");
        model.addColumn("药品名称");
        model.addColumn("药品库存");
        model.addColumn("销售数量");
        model.addColumn("销售额");
        model.addColumn("净利润");
//        model.addColumn("产地");
//        model.addColumn("药品规格");
//        model.addColumn("保质期");
//        model.addColumn("备注");
        table=new JTable(model);
        scrollpane=new JScrollPane(table);
        //  add(new JScrollPane(table),BorderLayout.CENTER);
        // scrollpane.add(table);
        Font font = new Font("微软雅黑", Font.BOLD, 16);
        Font font1 = new Font("楷体", Font.PLAIN, 16);
        labelA = new JLabel("药品编号");
        labelB = new JLabel("药品名称");

        txt1 = new JTextField(10);
        txt2 = new JTextField(10);
        txtArea=new JTextArea("查看所有药品的销售情况？请直接点击统计！");
//        model.setForeground(Color.black);
//        model.setFont(font1);

        button1 = new JButton("统计");
        button1.addActionListener(this);
        button2 = new JButton("返回");
        button2.addActionListener(this);

        labelA.setFont(font);
        labelB.setFont(font);

        txtArea.setFont(font1);
        //txtArea.setForeground(Color.red);
        add(labelA);
        labelA.setBounds(100, 20, 100, 100);
        labelA.setForeground(Color.blue);
        add(txt1);
        txt1.setBounds(200, 50, 200, 30);
        add(labelB);
        labelB.setBounds(100, 70, 100, 100);
        labelB.setForeground(Color.blue);
        add(txt2);
        txt2.setBounds(200, 100, 200, 30);

        add(button1);
        button1.setBounds(200, 500, 80, 30);
        add(button2);
        button2.setBounds(320, 500, 80, 30);
        //

        add(txtArea);
        txtArea.setBounds(50,200,700,250);
        scrollpane.setBounds(50,200,700,250);

        //scrollpane.setViewportView(txtArea);
        setTitle("药品销售情况统计");
        button1.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);

        setLayout(null);


    }
    void profile() {
        String sql=null;
        String sql1=null;
        txtArea.setVisible(false);
        add(scrollpane,BorderLayout.CENTER);
        if (txt1.getText().equals("")&&txt2.getText().equals("")) {
            sql ="Select * From medicine ";
            sql1 ="Select * From sale ";
        }
        else if (txt1.getText().equals("")){
            sql ="Select * From medicine where Name='"+txt2.getText()+"'";
            sql1 ="Select * From sale where 药品名称='"+txt2.getText()+"'";
        }
        else if (txt2.getText().equals("")){
            sql ="Select * From medicine where Num='"+txt1.getText()+"'";
            sql1 ="Select * From sale where 药品编号='"+txt1.getText()+"'";
        }
        try{
            Connection conn = DataBaseConnection.getConnection();
            Statement statement = conn.createStatement();
            ResultSet RS = statement.executeQuery(sql);

            Connection conn1 = DataBaseConnection.getConnection();
            Statement statement1 = conn1.createStatement();
            ResultSet RS1 = statement1.executeQuery(sql1);



            while(RS.next()&&RS1.next()){
                s1=RS1.getString("药品编号");
                s2=RS1.getString("药品名称");

                s3=RS.getString("count");

                s4=RS.getString("price");
                s5=RS1.getString("销售数量");
                s6=RS1.getString("销售额");
                f=Float.parseFloat(s6);
                f1=Float.parseFloat(s4);
                i=Integer.parseInt(s5);
                f2=f-i*f1;
                s8=""+f2;
                String[] row={s1,s2,s3,s5,s6,s8};
                model.addRow(row);

               //conn.close(); // this.txtArea.append(s1+"    "+s2+"   "+s3+"     "+s4+"     "+s5+"    "+s6+"     "+s7+"     "+s8+"    "+s9+"    "+s10+"\n");
            }


        }catch (SQLException e){
            e.printStackTrace();
        }




    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(button1)) {

            profile();
//            txt1.setText(s1);
//            txt2.setText(s2);

        }
        if (e.getSource().equals(button2)) {
            new Menu();
            dispose();
        }
    }

    public static void main(String[] args) {
        Profile s = new Profile();
        s.setBounds(100, 100, 800, 600);
        s.setVisible(true);
        s.setLocationRelativeTo(null);
        s.setResizable(false);

    }

}
