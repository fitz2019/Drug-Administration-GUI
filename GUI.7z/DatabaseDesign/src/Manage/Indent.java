package Manage;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import  JDBC.DataBaseConnection;
import javax.swing.table.*;
public class Indent extends JFrame implements ActionListener{
    private static final long serialVersionUID = -7247281774110864164L;

    JLabel labelA, labelB,labelC;
    JTextField txt1, txt2;
    JButton button1, button2;

    JTextArea txtArea;
    JScrollPane scrollpane;
    DefaultTableModel model;
    JTable table;
    String s1, s2, s3, s4, s5, s6, s7,s8,s9,s10;

    public Indent() {

        model=new DefaultTableModel();
        model.addColumn("订单编号");
        model.addColumn("客户编号");
        model.addColumn("药品编号");
        model.addColumn("订单金额");


        table=new JTable(model);
        scrollpane=new JScrollPane(table);

        Font font = new Font("微软雅黑", Font.BOLD, 16);
        Font font1 = new Font("楷体", Font.PLAIN, 16);
        labelA = new JLabel("订单编号");

        labelC=new JLabel("下面是您查询的订单信息");
        txt1 = new JTextField(10);

        txtArea=new JTextArea("查询所有订单信息？请直接点击查询！");
//        model.setForeground(Color.black);
//        model.setFont(font1);

        button1 = new JButton("查询");
        button1.addActionListener(this);
        button2 = new JButton("返回");
        button2.addActionListener(this);

        labelA.setFont(font);

        labelC.setFont(font);
        txtArea.setFont(font1);
        //txtArea.setForeground(Color.red);
        add(labelA);
        labelA.setBounds(100, 20, 100, 100);
        labelA.setForeground(Color.blue);
        add(txt1);
        txt1.setBounds(200, 50, 200, 30);


        add(labelC);
        labelC.setBounds(180, 130, 500, 100);
        labelC.setForeground(Color.red);
        add(button1);
        button1.setBounds(200, 500, 80, 30);
        add(button2);
        button2.setBounds(320, 500, 80, 30);
        //

        add(txtArea);
        txtArea.setBounds(50,200,700,250);
        scrollpane.setBounds(50,200,700,250);

        //scrollpane.setViewportView(txtArea);
        setTitle("查询订单信息");
        button1.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);

        setLayout(null);


    }
    void indent() {
        String sql=null;
        add(scrollpane,BorderLayout.CENTER);
        txtArea.setVisible(false);
        if (txt1.getText().equals("")) {
            sql ="Select * From indent ";
        }

        else  {
            sql ="Select * From indent where 订单编号='"+txt1.getText()+"'";
        }
        try{
            Connection conn = DataBaseConnection.getConnection();
            Statement statement = conn.createStatement();
            ResultSet RS = statement.executeQuery(sql);


            while(RS.next()){
                s1=RS.getString("订单编号");
                s2=RS.getString("客户编号");
                s3=RS.getString("药品编号");
                s4=RS.getString("订单金额");


                String[] row={s1,s2,s3,s4};
                model.addRow(row);
                // this.txtArea.append(s1+"    "+s2+"   "+s3+"     "+s4+"     "+s5+"    "+s6+"     "+s7+"     "+s8+"    "+s9+"    "+s10+"\n");
            }
        }catch (SQLException e){
            e.printStackTrace();
        }


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(button1)) {

            indent();
//            txt1.setText(s1);
//            txt2.setText(s2);

        }
        if (e.getSource().equals(button2)) {
            new Menu();
            dispose();
        }
    }

    public static void main(String[] args) {
        Indent s = new Indent();
        s.setBounds(100, 100, 800, 600);
        s.setVisible(true);
        s.setLocationRelativeTo(null);
        s.setResizable(false);

    }
}
