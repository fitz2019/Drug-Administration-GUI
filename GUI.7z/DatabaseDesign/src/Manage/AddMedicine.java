package Manage;
import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import JDBC.DataBaseConnection;
public class AddMedicine extends JFrame implements ActionListener{
    private static final long serialVersionUID = -364466147708286086L;
    JLabel labelA,labelB,labelC,labelD,labelE,labelF,labelG,labelH,labelI,labelJ;
    JTextField txt0,txt1,txt2,txt3,txt4,txt5,txt6,txt7,txt8,txt9;
    JButton button1,button2,button3;
    Connection con;
    Statement sql;
    ResultSet rs;
    String s1,s2,s3,s4,s5,s6,s7,s8,s9,s10;
    public AddMedicine() {
        Font font=new Font("微软雅黑",Font.BOLD,16);
        labelA=new JLabel("药品编号");
        labelB=new JLabel("药品名称");
        labelC=new JLabel("药品剂型");
        labelD=new JLabel("数量");
        labelE=new JLabel("进价");
        labelF=new JLabel("单价");
        labelG=new JLabel("产地");
        labelH=new JLabel("规格");
        labelI=new JLabel("保质期");
        labelJ=new JLabel("备注");
        txt0=new JTextField(10);
        txt1=new JTextField(10);
        txt2=new JTextField(10);
        txt3=new JTextField(10);
        txt4=new JTextField(10);
        txt5=new JTextField(10);
        txt6=new JTextField(10);
        txt7=new JTextField(10);
        txt8=new JTextField(10);
        txt9=new JTextField(10);
        button1=new JButton("添加");
        button1.addActionListener(this);
        button2=new JButton("清空");
        button2.addActionListener(this);
        button3=new JButton("返回");
        button3.addActionListener(this);
        labelA.setFont(font);
        labelB.setFont(font);
        labelC.setFont(font);
        labelD.setFont(font);
        labelE.setFont(font);
        labelF.setFont(font);
        labelG.setFont(font);
        labelH.setFont(font);
        labelI.setFont(font);
        labelJ.setFont(font);
        labelA.setForeground(Color.blue);
        labelB.setForeground(Color.blue);
        labelC.setForeground(Color.blue);
        labelD.setForeground(Color.blue);
        labelE.setForeground(Color.blue);
        labelF.setForeground(Color.blue);
        labelG.setForeground(Color.blue);
        labelH.setForeground(Color.blue);
        labelI.setForeground(Color.blue);
        labelJ.setForeground(Color.blue);
        labelA.setBounds(100,0,100,100);
        labelB.setBounds(100,50,100,100);
        labelC.setBounds(100,100,100,100);
        labelD.setBounds(100,150,100,100);
        labelE.setBounds(100,200,100,100);
        labelF.setBounds(100,250,100,100);
        labelG.setBounds(100,300,100,100);
        labelH.setBounds(100,350,100,100);
        labelI.setBounds(100,400,100,100);
        labelJ.setBounds(100,450,100,100);
        txt0.setBounds(230,30,200,40);
        txt1.setBounds(230,80,200,40);
        txt2.setBounds(230,130,200,40);
        txt3.setBounds(230,180,200,40);
        txt4.setBounds(230,230,200,40);
        txt5.setBounds(230,280,200,40);
        txt6.setBounds(230,330,200,40);
        txt7.setBounds(230,380,200,40);
        txt8.setBounds(230,430,200,40);
        txt9.setBounds(230,480,200,40);
        button1.setBounds(230,600,80,30);
        button2.setBounds(350,600,80,30);
        button3.setBounds(520,640,80,30);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);
        button3.setBackground(Color.LIGHT_GRAY);
        button3.setForeground(Color.red);
        add(labelA);
        add(labelB);
        add(labelC);
        add(labelD);
        add(labelE);
        add(labelF);
        add(labelG);
        add(labelH);
        add(labelI);
        add(labelJ);
        add(txt0);
        add(txt1);
        add(txt2);
        add(txt3);
        add(txt4);
        add(txt5);
        add(txt6);
        add(txt7);
        add(txt8);
        add(txt9);
        add(button1);
        add(button2);
        add(button3);
        setTitle("添加药品信息");
        setLayout(null);
        setBounds(100, 100, 600, 700);
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
    }
    public void addmedicine(){
        s1=txt0.getText();
        s2=txt1.getText();
        s3=txt2.getText();
        s4=txt3.getText();
        s5=txt4.getText();
        s6=txt5.getText();
        s7=txt6.getText();
        s8=txt7.getText();
        s9=txt8.getText();
        s10=txt9.getText();
        if (s1.equals("") || s2.equals("") || s3.equals("") || s4.equals("")||s5.equals("")||s6.equals("") || s7.equals("") || s8.equals("") || s9.equals("")||s10.equals("")) {
            JOptionPane.showMessageDialog(this, "请填写完整！", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        else{
            String sql = "insert into medicine"
                    + " values (`" + s1 + "`,`" + s2 + "`,`" + s3 + "`,`" + s4 + "`,`" + s5 + "`,`" + s6 + "`,`" + s7 + "`,`" + s8 + "`,`" + s9 + "`,`" + s10 + "`)";

            try{

                //String sql2 = "insert into medicine"
                        //+ " values (`" + s1 + "`,`" + s2 + "`,`" + s3 + "`,`" + s4 + "`,`" + s5 + "`,`" + s6 + "`,`" + s7 + "`,`" + s8 + "`,`" + s9 + "`,`" + s10 + "`)";


                Connection conn = DataBaseConnection.getConnection();
                Statement statement = conn.createStatement();
                int i = statement.executeUpdate(sql);
                System.out.println();
                JOptionPane.showMessageDialog(this, "药品添加成功！", "恭喜", JOptionPane.WARNING_MESSAGE);
            }catch (SQLException e){
                e.printStackTrace();

            }

        }
    }
    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource().equals(button1)) {
            addmedicine();
        }
        else if (e.getSource().equals(button2)) {
            txt0.setText("");
            txt1.setText("");
            txt2.setText("");
            txt3.setText("");
            txt4.setText("");
            txt5.setText("");
            txt6.setText("");
            txt7.setText("");
            txt8.setText("");
            txt9.setText("");

        }
        else if (e.getSource().equals(button3)) {
            new Menu();
            dispose();
        }
    }
    public static void main(String[] args) {
       new AddMedicine();


    }
}
