package Manage;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import  JDBC.DataBaseConnection;
import javax.swing.table.*;
public class Search extends JFrame implements ActionListener{
    private static final long serialVersionUID = -7247281774110864164L;

    JLabel labelA, labelB,labelC;
    JTextField txt1, txt2;
    JButton button1, button2;

    JTextArea txtArea;
    JScrollPane scrollpane;
    DefaultTableModel model;
    JTable table;
    String s1, s2, s3, s4, s5, s6, s7,s8,s9,s10;

    public Search() {

        model=new DefaultTableModel();
        model.addColumn("药品编号");
        model.addColumn("药品名称");
        model.addColumn("药品剂型");
        model.addColumn("药品库存");
        model.addColumn("药品进价");
        model.addColumn("药品单价");
        model.addColumn("产地");
        model.addColumn("药品规格");
        model.addColumn("保质期");
        model.addColumn("备注");
        table=new JTable(model);
        scrollpane=new JScrollPane(table);
      //  add(new JScrollPane(table),BorderLayout.CENTER);
       // scrollpane.add(table);
        Font font = new Font("微软雅黑", Font.BOLD, 16);
        Font font1 = new Font("楷体", Font.PLAIN, 16);
        labelA = new JLabel("药品编号");
        labelB = new JLabel("药品名称");
        labelC=new JLabel("下面是您查询的药品信息");
        txt1 = new JTextField(10);
        txt2 = new JTextField(10);
        txtArea=new JTextArea("查询所有药品信息？请直接点击查询！");
//        model.setForeground(Color.black);
//        model.setFont(font1);

        button1 = new JButton("查询");
        button1.addActionListener(this);
        button2 = new JButton("返回");
        button2.addActionListener(this);

        labelA.setFont(font);
        labelB.setFont(font);
        labelC.setFont(font);
        txtArea.setFont(font1);
        //txtArea.setForeground(Color.red);
        add(labelA);
        labelA.setBounds(100, 20, 100, 100);
        labelA.setForeground(Color.blue);
        add(txt1);
        txt1.setBounds(200, 50, 200, 30);
        add(labelB);
        labelB.setBounds(100, 70, 100, 100);
        labelB.setForeground(Color.blue);
        add(txt2);
        txt2.setBounds(200, 100, 200, 30);
        add(labelC);
        labelC.setBounds(180, 130, 500, 100);
        labelC.setForeground(Color.red);
        add(button1);
        button1.setBounds(200, 500, 80, 30);
        add(button2);
        button2.setBounds(320, 500, 80, 30);
        //

        add(txtArea);
        txtArea.setBounds(50,200,700,250);
        scrollpane.setBounds(50,200,700,250);

        //scrollpane.setViewportView(txtArea);
        setTitle("查询药品信息");
        button1.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
        button1.setBackground(Color.LIGHT_GRAY);
        button1.setForeground(Color.red);
        button2.setBackground(Color.LIGHT_GRAY);
        button2.setForeground(Color.red);
//        setBounds(100, 100, 800, 600);
//       setVisible(true);
//       setLocationRelativeTo(null);
//        setResizable(false);
        setLayout(null);


    }
    void search() {
        String sql=null;
        add(scrollpane,BorderLayout.CENTER);
        txtArea.setVisible(false);
        if (txt1.getText().equals("")&&txt2.getText().equals("")) {
            sql ="Select * From medicine  ";
        }
        else if (txt1.getText().equals("")){
             sql ="Select * From medicine where Name like '%"+txt2.getText()+"%'";
        }
        else if (txt2.getText().equals("")){
            sql ="Select * From medicine where Num='"+txt1.getText()+"'" ;
        }
            try{
                Connection conn = DataBaseConnection.getConnection();
                Statement statement = conn.createStatement();
                ResultSet RS = statement.executeQuery(sql);
                //txtArea.setText("药品编号   药品名称    药品剂型    药品库存    药品进价    药品单价    产地      药品规格    保质期     备注\n");

                while(RS.next()){
                    s1=RS.getString("Num");
                    s2=RS.getString("Name");
                    s3=RS.getString("state");
                    s4=RS.getString("count");
                    s5=RS.getString("price");
                    s6=RS.getString("purchase");
                    s7=RS.getString("origin");
                    s8=RS.getString("specification");
                    s9=RS.getString("date");
                    s10=RS.getString("remark");
                    String[] row={s1,s2,s3,s4,s5,s6,s7,s8,s9,s10};
                    model.addRow(row);
                   // this.txtArea.append(s1+"    "+s2+"   "+s3+"     "+s4+"     "+s5+"    "+s6+"     "+s7+"     "+s8+"    "+s9+"    "+s10+"\n");
                }
            }catch (SQLException e){
                e.printStackTrace();
            }


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(button1)) {

            search();
//            txt1.setText(s1);
//            txt2.setText(s2);

        }
        if (e.getSource().equals(button2)) {
            new Menu();
            dispose();
        }
    }

    public static void main(String[] args) {
        Search s = new Search();
        s.setBounds(100, 100, 800, 600);
        s.setVisible(true);
        s.setLocationRelativeTo(null);
        s.setResizable(false);

    }

}
