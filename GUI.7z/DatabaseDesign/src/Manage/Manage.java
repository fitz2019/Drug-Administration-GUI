package Manage;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class Welcome extends JFrame implements ActionListener{
    private static final long serialVersionUID = -1564219685176362136L;
    JButton button1, button2;

    JLabel labelC;


    public Welcome() {

        String path = "Images/b.jpg";
        setSize(600, 400);
        //设置位置
        //setLocation(200, 50);
        ImageIcon background = new ImageIcon(path);
        JLabel label = new JLabel(background);
        // 把标签的大小位置设置为图片刚好填充整个面板
        label.setBounds(0, 0, this.getWidth(), this.getHeight());
        // 把内容窗格转化为JPanel，否则不能用方法setOpaque()来使内容窗格透明
        JPanel imagePanel = (JPanel) this.getContentPane();
        imagePanel.setOpaque(false);
        // 把背景图片添加到分层窗格的最底层作为背景
        this.getLayeredPane().setLayout(null);
        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));

        Font font2 = new Font("微软雅黑", Font.BOLD, 20);


        labelC = new JLabel("欢迎来到药品销售管理系统！");
        labelC.setForeground(Color.RED);
        labelC.setFont(font2);

        button1 = new JButton("登录");
        button1.addActionListener(this);
        button2 = new JButton("注册");
        button2.addActionListener(this);
        button1.setBackground(Color.cyan);
        button1.setForeground(Color.red);
        button2.setBackground(Color.CYAN);
        button2.setForeground(Color.red);
        labelC.setBounds(180, 0, 500, 100);

        button1.setBounds(200, 250, 80, 30);
        button2.setBounds(320, 250, 80, 30);

        add(labelC);

        add(button1);

        button1.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);

        add(button2);
       // setVisible(true);
        setLayout(null);

    }

    @SuppressWarnings("deprecation")
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource().equals(button1)) {
                new AdLogin();
                this.dispose();
            }
        else if (e.getSource().equals(button2)){
            Register pr =new Register();
            pr.setBounds(100, 100, 600, 500);
            pr.setVisible(true);
            pr.setLocationRelativeTo(null);
            }
        }


    }

public class Manage {
    public static void main(String[] args) {
        Welcome frm = new Welcome();
        frm.setTitle("药品销售管理系统");
        frm.setBounds(200, 200, 600, 400);
        frm.setVisible(true);
        frm.setLocationRelativeTo(null);
        frm.setResizable(false);

    }
}
