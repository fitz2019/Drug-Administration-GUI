package Manage;

import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

public class Menu extends JFrame  implements ActionListener{
    private static final long serialVersionUID = 1L;

    JButton button1,button2,button3,button4,button5,button6,button7,button8,button9;
    Menu(){
        String path = "Images/003.jpg";
        setSize(600, 600);
        //设置位置
        //setLocation(200, 50);
        ImageIcon background = new ImageIcon(path);
        JLabel label = new JLabel(background);
        // 把标签的大小位置设置为图片刚好填充整个面板
        label.setBounds(0, 0, this.getWidth(), this.getHeight());
        // 把内容窗格转化为JPanel，否则不能用方法setOpaque()来使内容窗格透明
        JPanel imagePanel = (JPanel) this.getContentPane();
        imagePanel.setOpaque(false);
        // 把背景图片添加到分层窗格的最底层作为背景
        this.getLayeredPane().setLayout(null);
        this.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));
        button1=new JButton("添加药品");
        button1.addActionListener(this);
        button2=new JButton("查询药品");
        button2.addActionListener(this);
        button3=new JButton("修改药品信息");
        button3.addActionListener(this);
        button4=new JButton("删除药品信息");
        button4.addActionListener(this);

        button5=new JButton("出售药品");
        button5.addActionListener(this);
        button6=new JButton("客户信息");
        button6.addActionListener(this);
        button8=new JButton("订单信息");
        button8.addActionListener(this);
        button9=new JButton("销售状况统计");
        button9.addActionListener(this);
        button7=new JButton("退出");
        button7.addActionListener(this);
        button7.setBackground(Color.cyan);
      //  button7.setForeground(Color.red);
        setLayout(null);
        button1.setBackground(Color.cyan);
       // button1.setForeground(Color.red);
        button2.setBackground(Color.cyan);
       // button2.setForeground(Color.red);
        button3.setBackground(Color.cyan);
        //button3.setForeground(Color.red);
        button4.setBackground(Color.cyan);
       // button4.setForeground(Color.red);
        button5.setBackground(Color.cyan);
       // button5.setForeground(Color.red);
        button6.setBackground(Color.cyan);
        //button6.setForeground(Color.red);
        button8.setBackground(Color.cyan);
       // button8.setForeground(Color.red);
        button9.setBackground(Color.cyan);
        button1.setBounds(180, 20, 220, 50);
        button2.setBounds(180, 90, 220, 50);
        button3.setBounds(180, 160, 220, 50);
        button4.setBounds(180, 230, 220, 50);
        button5.setBounds(180, 300, 220, 50);
        button6.setBounds(180, 370, 220, 50);
        button8.setBounds(180, 440, 220, 50);
        button9.setBounds(180, 510, 220, 50);
        button7.setBounds(530, 540, 70, 30);

        add(button1);
        add(button2);
        add(button3);
        add(button4);
        add(button5);
        add(button6);
        add(button7);
        add(button8);
        add(button9);
        setTitle("药品销售管理系统主菜单");
        setBounds(100,100,600,600);
        setVisible(true);
        setLocationRelativeTo(null);
        setResizable(false);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(button1)) {
              new AddMedicine();
              dispose();
//		      setVisible(false);
        }
        else if(e.getSource().equals(button2)){
             Search s=new Search();
            s.setBounds(100, 100, 800, 600);
            s.setVisible(true);
            s.setLocationRelativeTo(null);
            s.setResizable(false);
            dispose();
            //	setVisible(false);
        }
        else if (e.getSource().equals(button3)) {
            new Update();
            dispose();

        }
        else if (e.getSource().equals(button4)) {
            Delete delete=new Delete();
            delete.setBounds(100,100,600,500);
            delete.setVisible(true);
            delete.setLocationRelativeTo(null);
            dispose();
            //setVisible(false);
        }
        else if (e.getSource().equals(button5)) {
        Sale sale = new Sale();
        sale.setBounds(100, 100, 600, 500);
        sale.setLocationRelativeTo(null);
        sale.setVisible(true);
        dispose();
        }
        else if (e.getSource().equals(button6)) {
            User s = new User();
            s.setBounds(100, 100, 800, 600);
            s.setVisible(true);
            s.setLocationRelativeTo(null);
            s.setResizable(false);
            dispose();

        }
        else if(e.getSource().equals(button8)){
            Indent s = new Indent();
            s.setBounds(100, 100, 800, 600);
            s.setVisible(true);
            s.setLocationRelativeTo(null);
            s.setResizable(false);
            dispose();

        }
        else if(e.getSource().equals(button9)){


            Profile s = new Profile();
            s.setBounds(100, 100, 800, 600);
            s.setVisible(true);
            s.setLocationRelativeTo(null);
            s.setResizable(false);
            dispose();
        }
        else if(e.getSource().equals(button7)){
            System.exit(0);
        }
    }
    public static void main(String[] args) {
        new Menu();

    }
}


