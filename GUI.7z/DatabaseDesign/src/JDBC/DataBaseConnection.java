package JDBC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DataBaseConnection {



    private static String DriverName ="com.mysql.jdbc.Driver";
    private static String URL = "jdbc:mysql://localhost:3306/database?serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=UTF-8";
    private static String DBUser = "root";
    private static String DBPassword = "123456";
    private static Connection conn = null;
    static {
        try{
            Class.forName(DriverName);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static Connection getConnection() throws SQLException {
        if (conn == null){
            conn = DriverManager.getConnection(URL, DBUser, DBPassword);
            return conn;
        }else return conn;
    }

    public void close() {
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public static void main(String[] args) {

        try {
            Connection connection = DataBaseConnection.getConnection();
            if (connection != null) {
                System.out.println("数据库连接成功！");
            } else {
                System.out.println("数据库连接失败");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
